$(document).ready(function () {
    // Open Login Modal
    $('.login-btn, .switch-to-login').on('click', function (e) {
        e.preventDefault();
        $('.modal-overlay').removeClass('active');
        $('#login-modal').addClass('active');
    });

    // Open Signup Modal
    $('.signup-btn, .switch-to-signup').on('click', function (e) {
        e.preventDefault();
        $('.modal-overlay').removeClass('active');
        $('#signup-modal').addClass('active');
    });

    // Open Ask Question Modal
    $('.open-ask-modal').on('click', function (e) {
        e.preventDefault();
        $('.modal-overlay').removeClass('active');
        $('#ask-modal').addClass('active');
    });

    // Close Modal via close button
    $('.close-modal').on('click', function () {
        $(this).closest('.modal-overlay').removeClass('active');
    });

    // Close Modal when clicking outside the modal box
    $('.modal-overlay').on('click', function (e) {
        if ($(e.target).hasClass('modal-overlay')) {
            $(this).removeClass('active');
        }
    });
});
